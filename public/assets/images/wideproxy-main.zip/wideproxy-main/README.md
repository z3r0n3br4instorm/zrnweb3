# wideproxy
Program that will apply the proxy address systemwide.


Usage :
compile the program using gcc
>>gcc sys_wide_prox.c -o wideproxy && gcc start_chrome.c -o start_chrome

Then run it
>>sudo ./wideproxy xxx.xxx.xxx.xxx:port
